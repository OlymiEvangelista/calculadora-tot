export interface HelpResource {
  id: string;
  title: string;
  type: 'video' | 'pdf';
  tag: string;
  description: string;
  youtubeUrl?: string;
}

export interface CalculationResult {
  days: number;
  dailyValue: number;
  credit: number;
  finalValue: number;
}

export interface CanvasBlock {
  id: string;
  title: string;
  icon: string;
  color: string;
  content: string[];
  details: string;
}
