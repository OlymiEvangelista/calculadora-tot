import React, { useState } from 'react';
import { Search, MonitorPlay, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';
import { HelpResource } from '../types';

const RESOURCES: HelpResource[] = [
  { 
    id: '1', 
    title: 'Como Realizar o Lançamento e Ajuste de TOT no Sistema', 
    type: 'video', 
    tag: 'Cobrança', 
    description: 'Aprenda o passo a passo completo para lançar congelamentos, identificar as datas de cobrança e garantir o faturamento pro-rata correto do aluno.',
    youtubeUrl: 'https://www.youtube.com/watch?v=scL_I74uXf4'
  },
  { 
    id: '2', 
    title: 'Entendendo a Regra de Pro-Rata Smart Fit', 
    type: 'video', 
    tag: 'Financeiro', 
    description: 'Vídeo explicativo sobre como o sistema calcula os dias de uso real (dias fora) e rebate os créditos gerados pelo período de congelamento.',
    youtubeUrl: 'https://www.youtube.com/watch?v=NOnmB94QW_A'
  },
  { 
    id: '3', 
    title: 'Como Tratar Erros de Cobrança e Inconsistências de Lançamento', 
    type: 'video', 
    tag: 'Suporte', 
    description: 'Guia de ação rápida para quando o aluno alega cobrança indevida no período em que esteve ausente da unidade.',
    youtubeUrl: 'https://www.youtube.com/watch?v=VAsdf8-M2co'
  },
  { 
    id: '4', 
    title: 'Tutorial: Gestão de Contratos e Portal do Aluno', 
    type: 'video', 
    tag: 'Treinamento', 
    description: 'Visão geral das funcionalidades de planos, datas de vencimento, e sincronização de pedidos e parcelas no GPO da Smart Fit.',
    youtubeUrl: 'https://www.youtube.com/watch?v=QpT95s_4H4Y'
  },
  { 
    id: '5', 
    title: 'Dicas Extras: Como engajar o aluno no retorno pós-congelamento', 
    type: 'video', 
    tag: 'Unidades', 
    description: 'Dicas comportamentais e táticas de acolhimento para reduzir a evasão/churn da sua unidade.',
    youtubeUrl: 'https://www.youtube.com/watch?v=7h2Y9G6wPlk'
  }
];

export default function HelpCenter() {
  const [query, setQuery] = useState('');

  const filtered = RESOURCES.filter(r => 
    r.title.toLowerCase().includes(query.toLowerCase()) || 
    r.description.toLowerCase().includes(query.toLowerCase()) ||
    r.tag.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-12">
      <div className="bg-indigo-600 rounded-[32px] p-10 md:p-16 text-center text-white relative overflow-hidden shadow-2xl shadow-indigo-950/50">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
        
        <h2 className="text-3xl md:text-5xl font-black mb-4 relative z-10 tracking-tight">Central de Ajuda</h2>
        <p className="text-indigo-100 mb-10 max-w-2xl mx-auto relative z-10 text-lg font-medium opacity-80">
          Tutoriais rápidos gravados em vídeo e disponibilizados no YouTube para facilitar a rotina da sua unidade.
        </p>
        
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="relative">
            <Search className="absolute left-6 top-5 text-slate-400" size={24} />
            <input 
              type="text" 
              className="w-full pl-16 pr-8 py-5 rounded-2xl text-slate-900 shadow-2xl focus:ring-8 focus:ring-white/10 outline-none text-lg font-bold"
              placeholder="Pesquise por termos técnicos ou tutoriais..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((resource) => (
          <motion.a 
            key={resource.id}
            href={resource.youtubeUrl}
            target="_blank"
            rel="noopener noreferrer"
            layout
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bento-card hover:bg-slate-800/80 group flex flex-col cursor-pointer border-red-500/10 hover:border-red-500/30 transition-all"
          >
            <div className="flex justify-between items-start mb-6">
              <span className="px-2.5 py-1 rounded text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 bg-red-500/10 text-red-500 border border-red-500/20">
                <MonitorPlay size={12} className="fill-red-500" />
                YouTube Tutorial
              </span>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-950 px-2 py-1 rounded-md border border-slate-800">{resource.tag}</span>
            </div>
            <h4 className="text-lg font-bold text-white mb-2 group-hover:text-red-400 transition-colors leading-tight">{resource.title}</h4>
            <p className="text-xs font-medium text-slate-400 mb-6 flex-1 leading-relaxed">{resource.description}</p>
            <div className="mt-auto pt-4 border-t border-slate-800 flex justify-between items-center text-xs font-black uppercase tracking-widest text-red-400 group-hover:text-red-300 transition-colors">
              <span className="flex items-center gap-1.5">
                Assistir Vídeo <ExternalLink size={12} />
              </span>
              <span className="group-hover:translate-x-1 transition-transform inline-block">→</span>
            </div>
          </motion.a>
        ))}
      </div>
    </div>
  );
}
