import React, { useState, useEffect } from 'react';
import { Calculator as CalcIcon, Calendar, CheckCircle2, AlertTriangle, ArrowRight, History } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CalculationResult } from '../types';

interface BillingCycle {
  month: string;
  billingDate: Date;
  status: 'Pago' | 'Aguardando' | 'Processando';
  value: number;
  description: string;
  orderNumber: string;
  parcelNumber: number;
}

export default function Calculator() {
  const [mensalidade, setMensalidade] = useState<number | ''>('');
  const [diaCobranca, setDiaCobranca] = useState<number>(6);
  const [baseOrderId, setBaseOrderId] = useState<string>('');
  const [dataInicio, setDataInicio] = useState<string>('');
  const [dataFim, setDataFim] = useState<string>('');
  const [usarCobranca, setUsarCobranca] = useState<boolean>(false);
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [cycles, setCycles] = useState<BillingCycle[]>([]);
  const [error, setError] = useState<string | null>(null);

  const calculate = () => {
    if (!dataInicio || !dataFim) {
      setResult(null);
      setCycles([]);
      return;
    }

    // Use local time for date objects to match user expectations
    const start = new Date(dataInicio + 'T00:00:00');
    const end = new Date(dataFim + 'T00:00:00');

    if (end < start) {
      setError('A data de retorno não pode ser anterior à data de início.');
      setResult(null);
      setCycles([]);
      return;
    }

    setError(null);
    
    const mensalidadeValue = typeof mensalidade === 'number' ? mensalidade : 0;
    const dailyValue = mensalidadeValue / 30;
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

    // Calculo solicitado pelo usuário:
    // mensalidade % 30 dias = valor por dia
    // valor_por_dia x dias_foras = valor-pro-rata
    // valor-pro-rata - mensalidade = valor_final
    const credit = dailyValue * totalDays;
    // For visual consistency, valor_final can be negative depending on subtraction direction,
    // let's show exact value of the subtraction as absolute difference / remaining amount standard.
    const finalValue = Math.max(0, mensalidadeValue - credit);

    // --- Intelligent Billing Analysis ---
    const analyzedCycles: BillingCycle[] = [];
    
    if (usarCobranca) {
      // Check months starting from a bit before the freeze to show context
      const firstCycleDate = new Date(start);
      firstCycleDate.setMonth(firstCycleDate.getMonth() - 1);
      
      let current = new Date(firstCycleDate.getFullYear(), firstCycleDate.getMonth(), 1);
      let parcelCount = 1;
      const orderIdToDisplay = baseOrderId || '0.00';
      
      // Generate 6 cycles to match the scale of the image
      while (analyzedCycles.length < 6) {
        const bDate = new Date(current.getFullYear(), current.getMonth(), diaCobranca);
        const monthName = bDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
        
        let status: 'Pago' | 'Aguardando' | 'Processando' = 'Pago';
        let value = mensalidadeValue;
        let desc = '';

        const isFrozenOnBilling = bDate >= start && bDate <= end;
        
        if (isFrozenOnBilling) {
          value = 0;
          status = 'Pago'; // In the image, 0.00 is marked as "Pago" (adjusted)
          desc = `Congelamento: ${start.toLocaleDateString('pt-BR')} até ${end.toLocaleDateString('pt-BR')}`;
        } else if (bDate > end) {
          status = 'Aguardando';
          // Check if there was some active days in the cycle belonging to this bill
          const cycleStart = new Date(bDate);
          cycleStart.setMonth(cycleStart.getMonth() - 1);
          
          let activeDays = 0;
          let temp = new Date(cycleStart);
          while (temp < bDate) {
            if (temp < start || temp >= end) activeDays++;
            temp.setDate(temp.getDate() + 1);
          }

          if (activeDays < 30) {
            value = activeDays * dailyValue;
            desc = `Pro-rata: ${activeDays} dias utilizáveis`;
          } else {
            value = mensalidadeValue;
            desc = 'Cobrança integral agendada';
          }
        } else {
          // Before freeze
          status = 'Pago';
          value = (parcelCount === 1) ? Number((mensalidadeValue * 0.85).toFixed(2)) : mensalidadeValue; // Mocking partial or full
          desc = 'Faturamento processado';
        }

        analyzedCycles.push({
          month: monthName.charAt(0).toUpperCase() + monthName.slice(1),
          billingDate: bDate,
          status,
          value: Number(value.toFixed(2)),
          description: desc,
          orderNumber: orderIdToDisplay ? `${orderIdToDisplay}-${parcelCount.toString().padStart(2, '0')}` : '0.00',
          parcelNumber: parcelCount
        });

        current.setMonth(current.getMonth() + 1);
        parcelCount++;
      }
    }

    setCycles(analyzedCycles);

    setResult({
      days: totalDays,
      dailyValue,
      credit,
      finalValue
    });
  };

  useEffect(() => {
    calculate();
  }, [mensalidade, diaCobranca, baseOrderId, dataInicio, dataFim, usarCobranca]);

  return (
    <div className="space-y-8 pb-20">
      <header className="mb-4">
        <h2 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-1">Análise Inteligente</h2>
        <p className="text-2xl font-bold text-white">Calculadora de Ciclos TOT</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-6">
          <div className="bento-card space-y-6">
            <h3 className="text-xs font-black uppercase text-indigo-400 tracking-widest">Configuração do Plano</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Mensalidade (R$)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">R$</span>
                  <input 
                    type="number" 
                    className="w-full bg-slate-950/50 border border-slate-700 p-4 pl-12 rounded-2xl text-white font-bold focus:border-indigo-500 outline-none transition-all"
                    placeholder="Ex: 449"
                    value={mensalidade}
                    onChange={(e) => setMensalidade(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  />
                </div>
              </div>

              <div className="border-t border-slate-800/80 pt-4 mt-4">
                <label className="flex items-center gap-3 cursor-pointer group">
                  <div className="relative">
                    <input 
                      type="checkbox"
                      className="sr-only"
                      checked={usarCobranca}
                      onChange={(e) => setUsarCobranca(e.target.checked)}
                    />
                    <div className={`w-10 h-6 rounded-full transition-colors duration-200 ${usarCobranca ? 'bg-indigo-600' : 'bg-slate-800'}`}></div>
                    <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform duration-200 ${usarCobranca ? 'translate-x-4' : ''}`}></div>
                  </div>
                  <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider select-none group-hover:text-white transition-colors">
                    Habilitar Ciclos de Cobrança (GPO)
                  </span>
                </label>
              </div>

              <AnimatePresence>
                {usarCobranca && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }} 
                    animate={{ opacity: 1, height: 'auto' }} 
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="space-y-4 pt-2 overflow-hidden"
                  >
                    <div>
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">ID do Pedido Base</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-950/50 border border-slate-700 p-4 rounded-2xl text-white font-bold focus:border-indigo-500 outline-none transition-all uppercase"
                        value={baseOrderId}
                        onChange={(e) => setBaseOrderId(e.target.value)}
                        placeholder="Ex: 3351891"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Dia da Cobrança</label>
                      <select 
                        className="w-full bg-slate-950/50 border border-slate-700 p-4 rounded-2xl text-white font-bold focus:border-indigo-500 outline-none transition-all"
                        value={diaCobranca}
                        onChange={(e) => setDiaCobranca(parseInt(e.target.value))}
                      >
                        {[1, 6, 10, 15, 20, 25].map(d => (
                          <option key={d} value={d}>Dia {d.toString().padStart(2, '0')}</option>
                        ))}
                      </select>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="grid grid-cols-1 gap-4 pt-2 border-t border-slate-800/80">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Início Congelamento</label>
                  <input 
                    type="date" 
                    className="w-full bg-slate-950/50 border border-slate-700 p-4 rounded-2xl text-white text-xs font-bold focus:border-indigo-500 outline-none transition-all"
                    value={dataInicio}
                    onChange={(e) => setDataInicio(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Data de Retorno</label>
                  <input 
                    type="date" 
                    className="w-full bg-slate-950/50 border border-slate-700 p-4 rounded-2xl text-white text-xs font-bold focus:border-indigo-500 outline-none transition-all"
                    value={dataFim}
                    onChange={(e) => setDataFim(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bento-card bg-indigo-600 border-indigo-500 text-white p-6">
            <h4 className="text-[10px] font-black uppercase tracking-widest opacity-70 mb-3 flex items-center gap-2">
              <CheckCircle2 size={12} /> Regra de Negócio
            </h4>
            <p className="text-xs leading-relaxed font-medium">
              Se o aluno estiver congelado na data de cobrança, a mensalidade é zerada. No retorno, o sistema projeta o ajuste baseado no tempo de uso real fora do gelo.
            </p>
          </div>
        </div>

        <div className="lg:col-span-8 flex flex-col gap-6">
          {error && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl text-red-400 text-xs font-bold uppercase tracking-widest flex items-center gap-3">
              <AlertTriangle size={18} /> {error}
            </motion.div>
          )}

          {result ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bento-card flex justify-between items-center group">
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Dias Totais Afastado (Dias Foras)</p>
                    <p className="text-3xl font-black text-white">{result.days}</p>
                  </div>
                  <Calendar className="text-slate-700 group-hover:text-indigo-400 transition-colors" size={32} />
                </div>
                <div className="bento-card border-emerald-500/20 bg-emerald-500/5 flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-bold text-emerald-500/60 uppercase tracking-widest mb-1">Crédito Pro-Rata</p>
                    <p className="text-3xl font-black text-white">R$ {result.credit.toFixed(2).replace('.', ',')}</p>
                  </div>
                  <History className="text-emerald-500/20" size={32} />
                </div>
              </div>

              {/* Demonstração da Fórmula de Cálculo Pro-Rata solicitada pelo usuário */}
              <div className="bento-card border-slate-700/50 bg-slate-900/40 p-6 space-y-4">
                <h3 className="text-xs font-black uppercase text-indigo-400 tracking-[0.2em] flex items-center gap-2">
                  <CalcIcon size={14} className="text-indigo-400" /> Demonstração Matemática do Pro-Rata
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                  <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-wider mb-2">1. Valor por Dia</p>
                    <p className="text-xs font-mono text-slate-400 mb-1">mensalidade / 30 dias</p>
                    <p className="text-sm font-bold text-slate-300">R$ {Number(typeof mensalidade === 'number' ? mensalidade : 0).toFixed(2).replace('.', ',')} / 30 = </p>
                    <p className="text-lg font-black text-indigo-400 mt-1">R$ {result.dailyValue.toFixed(4).replace('.', ',')} <span className="text-[10px] text-slate-500 font-normal">/ dia</span></p>
                  </div>

                  <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-2">2. Valor Pro-Rata</p>
                    <p className="text-xs font-mono text-slate-450 mb-1">valor_por_dia x dias_foras</p>
                    <p className="text-sm font-bold text-slate-300">R$ {result.dailyValue.toFixed(2).replace('.', ',')} x {result.days} dias = </p>
                    <p className="text-lg font-black text-amber-400 mt-1">R$ {result.credit.toFixed(2).replace('.', ',')}</p>
                  </div>

                  <div className="bg-slate-950/40 p-4 rounded-xl border border-emerald-500/20 bg-emerald-500/5">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-wider mb-2">3. Valor Final</p>
                    <p className="text-xs font-mono text-slate-400 mb-1">mensalidade - valor-pro-rata</p>
                    <p className="text-sm font-bold text-slate-300">R$ {Number(typeof mensalidade === 'number' ? mensalidade : 0).toFixed(2).replace('.', ',')} - R$ {result.credit.toFixed(2).replace('.', ',')} = </p>
                    <p className="text-xl font-black text-emerald-400 mt-1">R$ {result.finalValue.toFixed(2).replace('.', ',')}</p>
                  </div>
                </div>
              </div>

              {usarCobranca && (
                <div className="bento-card">
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="text-xs font-black uppercase text-indigo-400 tracking-[0.2em] flex items-center gap-2">
                      <History size={14} /> Histórico de Cobranças (GPO)
                    </h3>
                    <div className="text-[10px] text-slate-500 font-bold uppercase">Base Order: #{baseOrderId || '0.00'}</div>
                  </div>

                  <div className="space-y-3">
                    {cycles.map((cycle, i) => (
                      <motion.div 
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className={`grid grid-cols-1 md:grid-cols-12 gap-4 items-center p-4 rounded-xl border transition-all ${
                          cycle.value === 0 ? 'bg-indigo-500/5 border-indigo-500/10' : 'bg-slate-950/30 border-slate-800'
                        }`}
                      >
                        <div className="md:col-span-1 text-center border-r border-slate-800 pr-4">
                          <p className="text-[10px] font-black text-slate-500 uppercase leading-none">Parcela</p>
                          <p className="text-lg font-bold text-white mt-1">{cycle.parcelNumber}</p>
                        </div>
                        
                        <div className="md:col-span-3">
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Vencimento</p>
                          <div className="flex items-center gap-2">
                            <Calendar size={12} className="text-indigo-400" />
                            <p className="text-sm font-bold text-slate-200">{cycle.billingDate.toLocaleDateString('pt-BR')}</p>
                          </div>
                        </div>

                        <div className="md:col-span-2">
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Status</p>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest ${
                            cycle.status === 'Pago' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                            'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                          }`}>
                            {cycle.status}
                          </span>
                        </div>

                        <div className="md:col-span-3">
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Número do Pedido</p>
                          <p className="text-xs font-mono text-slate-400">{cycle.orderNumber}</p>
                        </div>

                        <div className="md:col-span-3 text-right">
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Valor</p>
                          <p className={`text-xl font-black ${
                            cycle.value === 0 ? 'text-indigo-400' : 'text-white'
                          }`}>
                            R$ {cycle.value.toFixed(2).replace('.', ',')}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  
                  <div className="mt-8 pt-6 border-t border-slate-800/50 flex items-center gap-4 text-slate-500">
                     <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                     <p className="text-[10px] font-bold uppercase tracking-widest leading-none">Sistema de Melhoria Contínua - Smart Fit Hub</p>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bento-card flex-1 flex flex-col items-center justify-center opacity-20 py-20 text-center">
              <CalcIcon size={64} className="mb-4" />
              <p className="text-xs uppercase font-black tracking-[0.5em]">Insira as datas para análise</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
