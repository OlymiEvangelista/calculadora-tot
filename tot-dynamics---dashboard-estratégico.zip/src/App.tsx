/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Calculator as CalcIcon, 
  HelpCircle, 
  Menu,
  X,
  Settings,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Components
import Calculator from './components/Calculator';
import HelpCenter from './components/HelpCenter';

type Tab = 'calculator' | 'help';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('calculator');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const navigation = [
    { id: 'calculator', label: 'Calculadora', icon: CalcIcon },
    { id: 'help', label: 'Central de Ajuda', icon: HelpCircle },
  ];

  return (
    <div className="flex h-screen w-full overflow-hidden bg-brand-bg">
      {/* Sidebar Desktop */}
      <aside className={`bg-slate-900 border-r border-slate-800 text-white flex flex-col transition-all duration-300 no-print hidden lg:flex ${isSidebarOpen ? 'w-72' : 'w-20'}`}>
        <div className="p-8 flex items-center gap-3 border-b border-slate-800 shrink-0">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/20">
             <Settings className="text-white" size={18} />
          </div>
          {isSidebarOpen && (
            <div>
              <h1 className="text-lg font-black tracking-tighter leading-none">TOT Dynamics</h1>
              <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mt-1">Strategic Hub</p>
            </div>
          )}
        </div>

        <nav className="flex-1 p-4 space-y-2 mt-4">
          {navigation.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as Tab)}
              className={`w-full sidebar-item ${activeTab === item.id ? 'sidebar-item-active' : ''} ${!isSidebarOpen ? 'justify-center px-0' : ''}`}
            >
              <item.icon size={20} />
              {isSidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="w-full flex items-center justify-center p-3 hover:bg-slate-800 rounded-xl transition-colors text-slate-500"
          >
            <ChevronRight className={`transition-transform duration-300 ${isSidebarOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 h-full flex flex-col overflow-hidden relative">
        {/* Header no-print */}
        <header className="bg-brand-bg/50 backdrop-blur-md h-20 shrink-0 flex items-center justify-between px-8 no-print border-b border-slate-800/50">
          <div className="flex items-center gap-4">
            <button className="lg:hidden p-2 text-slate-400" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
              <Menu />
            </button>
            <h2 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em]">
              {navigation.find(n => n.id === activeTab)?.label}
            </h2>
          </div>
          <div className="flex items-center gap-6">
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div> Sessão Ativa
            </div>
            <div className="flex items-center gap-4 border-l border-slate-800 pl-6">
              <div className="text-right hidden md:block">
                <p className="text-sm font-bold text-slate-100">Alex Nascimento</p>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Gestor Regional</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-indigo-400">
                AN
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-12">
          <div className="max-w-7xl mx-auto w-full h-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="h-full"
              >
                {activeTab === 'calculator' && <Calculator />}
                {activeTab === 'help' && <HelpCenter />}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          >
            <motion.aside 
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              className="w-72 h-full bg-brand-blue"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center p-8 border-b border-white/10">
                <h1 className="text-xl font-black text-white">TOT Dynamics</h1>
                <X className="text-white cursor-pointer" onClick={() => setIsSidebarOpen(false)} />
              </div>
              <nav className="p-4 space-y-2 mt-4">
                {navigation.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as Tab);
                      setIsSidebarOpen(false);
                    }}
                    className={`w-full sidebar-item ${activeTab === item.id ? 'sidebar-item-active' : 'text-white'}`}
                  >
                    <item.icon size={22} className={activeTab === item.id ? 'text-sky-400' : 'text-blue-300'} />
                    <span>{item.label}</span>
                  </button>
                ))}
              </nav>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

